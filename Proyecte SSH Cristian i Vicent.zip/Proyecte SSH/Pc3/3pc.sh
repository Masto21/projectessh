#/bin/bash
export DISPLAY=':0'

firefox --kiosk /tmp/img3.html
